# # # load errormindR
# library(errormindR)
#
# # # example 1
# library(data.table)
# dt <- as.data.table(mtcars)
# dt[, .(cnt = .N), by = .("cyl", "gear")] |> minerr()
#
# # LLM solutions start -----------------------------------------------------
#
# # The error occurs because .("cyl", "gear") creates a character vector,
# # not a symbol or expression for grouping. data.table expects column names (unquoted).
# # To group by columns, use .(cyl, gear) instead.
#
# library(data.table)
# dt <- as.data.table(mtcars)
# dt[, .(cnt = .N), by = .(cyl, gear)]
#
# # LLM solutions end -------------------------------------------------------
#
# # example 2
# x <- c(TRUE, FALSE, TRUE)
#
#
# minerr(
#   if (x) {
#     print("x is TRUE")
#   }
# )
#
# # LLM solutions start -----------------------------------------------------
#
# # The error occurs because `if` requires a single logical value, but `x` is a logical vector of length > 1.
# # Use `ifelse` if you want to handle each element, or use `any(x)` or `all(x)` if you want to summarize.
#
# x <- c(TRUE, FALSE, TRUE)
#
# # To print when any element of x is TRUE:
# if (any(x)) {
#   print("x has at least one TRUE")
# }
#
# # Or vectorized operation:
# ifelse(x, "x is TRUE", "x is FALSE")
#
# # LLM solutions end -------------------------------------------------------
#
#
# # example 3
# library(ggplot2)
# library(dplyr)
# library(tibble)
#
# mtcars_mod <- mtcars %>%
#    rownames_to_column("car") %>%
#    mutate(
#      cyl = as.factor(cyl),
#      mpg_z = scale(mpg),
#      hp_log = log10(hp + 1),
#      wt_kg = wt * 1000,
#      power_to_weight = hp / wt
#    ) %>%
#    filter(mpg_z > 1.5 | cyl == 6) %>%
#    select(car, cyl, mpg_z, hp_log, wt_kg, power_to_weight)
#
#
# minerr(
#   mtcars_mod |>
#     ggplot(c(x = wt_kg, y = mpg_z)) + # error 1
#     geom_point(aes(color = cyl, size = power_to_weight)) +
#     geom_smooth(method = "loess", formula = y ~ x2) +   # error 2
#     theme_minimal() +
#     labs(
#       title = "Fuel Efficiency vs Weight",
#       subtitle = "Only cars with high mpg or 6 cylinders",
#       x = "Weight (kg)",
#       y = "MPG (z-score)",
#       caption = "Data: mtcars"
#     ) +
#     facet_wrap(~gearz), # error 3
#   chat = "There could be multiple errors"
# )
#
#
# # LLM solutions start -----------------------------------------------------
#
# # There are multiple errors in the code:
# # 1. `ggplot(c(x = wt_kg, y = mpg_z))` is incorrect. You should pass `aes(x = wt_kg, y = mpg_z)` inside `ggplot()` or `aes()` as argument.
# # 2. In `geom_smooth(method = "loess", formula = y ~ x2)`, the formula `y ~ x2` should be `y ~ x` unless you have a variable named `x2`.
# # 3. `facet_wrap(~gearz)` will fail because `gearz` does not exist in the data.
# # Here's the corrected code:
#
# library(ggplot2)
# library(dplyr)
# library(tibble)
#
# mtcars_mod <- mtcars %>%
#    rownames_to_column("car") %>%
#    mutate(
#      cyl = as.factor(cyl),
#      mpg_z = scale(mpg),
#      hp_log = log10(hp + 1),
#      wt_kg = wt * 1000,
#      power_to_weight = hp / wt
#    ) %>%
#    filter(mpg_z > 1.5 | cyl == 6) %>%
#    select(car, cyl, mpg_z, hp_log, wt_kg, power_to_weight, gear) # include `gear` if faceting
#
# # Corrected ggplot code
# mtcars_mod %>%
#   ggplot(aes(x = wt_kg, y = mpg_z)) +
#     geom_point(aes(color = cyl, size = power_to_weight)) +
#     geom_smooth(method = "loess", formula = y ~ x) +
#     theme_minimal() +
#     labs(
#       title = "Fuel Efficiency vs Weight",
#       subtitle = "Only cars with high mpg or 6 cylinders",
#       x = "Weight (kg)",
#       y = "MPG (z-score)",
#       caption = "Data: mtcars"
#     ) +
#     facet_wrap(~gear)
#
# # LLM solutions end -------------------------------------------------------
# # example 4 - logical error
# df <- data.frame(x = c("Jan", "Feb", "Mar", "Apr", "May", "June", "Jul"))
#
# df |> dplyr::filter(x == "Jun") |>
#   minerr(is_logical_error = TRUE,
#          chat = "expecting to get some record, but getting nothing")
# # LLM solutions start -----------------------------------------------------
#
# # Logical error: The code is filtering for "Jun", but the values in the 'x' column are "Jan", "Feb", "Mar", etc.
# # The correct value to match is "June", not "Jun".
# # To return records for June, update the filter condition as shown below.
#
# df <- data.frame(x = c("Jan", "Feb", "Mar", "Apr", "May", "June", "Jul"))
#
# df |> dplyr::filter(x == "June")
#
# # LLM solutions end -------------------------------------------------------
